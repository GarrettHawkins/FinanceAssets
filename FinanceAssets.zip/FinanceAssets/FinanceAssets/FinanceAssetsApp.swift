//
//  FinanceAssetsApp.swift
//  FinanceAssets
//
//  Created by Hawkins, Garrett - Student on 5/8/24.
//

import SwiftUI

@main
struct FinanceAssetsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
